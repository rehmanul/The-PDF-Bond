#!/bin/bash
set -e
echo "Starting Netlify deployment..."
# Create necessary directories
mkdir -p netlify/functions
mkdir -p static/js
mkdir -p static/css
mkdir -p static/img

# Install dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Copy static files
echo "Copying static files..."
cp -r templates/* static/
# Fixed redundant move command
touch static/index.html
cp -f static/api_keys.html static/api-keys.html 2>/dev/null || true
cp -f static/benefit_extraction.html static/benefit-extraction.html 2>/dev/null || true

# Make sure we have JS files
echo "Setting up JavaScript files..."
if [ ! -f static/js/script.js ]; then
  cp -r attached_assets/script.js static/js/script.js 2>/dev/null || echo "Warning: script.js not found"
fi
if [ ! -f static/js/api_keys.js ]; then
  cp -r attached_assets/api_keys.js static/js/api_keys.js 2>/dev/null || echo "Warning: api_keys.js not found"
fi
if [ ! -f static/js/benefit_extraction.js ]; then
  cp -r attached_assets/benefit_extraction.js static/js/benefit_extraction.js 2>/dev/null || echo "Warning: benefit_extraction.js not found"
fi

# Make sure we have CSS files
echo "Setting up CSS files..."
if [ ! -f static/css/style.css ]; then
  cp -r attached_assets/style.css static/css/style.css 2>/dev/null || echo "Warning: style.css not found"
fi

# Prepare Netlify functions
echo "Setting up Netlify functions..."
if [ ! -f netlify/functions/api.py ]; then
  cp -r attached_assets/api.py netlify/functions/api.py 2>/dev/null || echo "Warning: api.py not found"
fi

# Create an empty file to ensure directories exist
touch static/img/.gitkeep

# Ensure the netlify.toml file exists
if [ ! -f netlify.toml ]; then
  cp -r attached_assets/netlify.toml ./netlify.toml 2>/dev/null || echo "Warning: netlify.toml not found"
fi

echo "Netlify deployment setup complete!"
